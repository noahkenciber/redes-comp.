# GHOST.TRACE · OSINT Simulator

Simulador educacional de **OSINT** (inteligência em fontes abertas) com visual hacker: fundo animado com código verde caindo, terminal de consulta e relatório do alvo.

> ⚠️ **Tudo é fictício.** Nenhuma consulta real é feita. Nomes, e-mails, telefones, endereços, IPs e vazamentos são gerados aleatoriamente no navegador. Os e-mails usam domínios reservados (`.test`, `.invalid`, `.example`), os IPs usam faixas de documentação e o documento aparece mascarado.

## Funcionalidades

- **Fundo Matrix** animado em canvas (respeita `prefers-reduced-motion`)
- **Barra de pesquisa** para nome, e-mail, telefone ou @usuário
- **Varredura simulada** com log em tempo real e barra de progresso
- **Relatório do alvo** com dados pessoais, contatos, localização, redes sociais, IPs e dispositivos, vazamentos, linha do tempo e índice de exposição
- **Reiniciar pesquisa**: limpa a barra e remove as informações para consultar outro alvo
- **Aba de histórico**: pesquisas anteriores salvas no navegador (`localStorage`), com opção de reabrir ou limpar
- **Painel de estatísticas**: acessos ao site, investigações, suas investigações, operadores online, bases indexadas, fontes ativas, tempo de resposta, uptime, feed de atividade ao vivo
- A mesma entrada sempre gera o mesmo perfil (gerador com semente)

## Estrutura

```
ghost-trace/
├── index.html   # estrutura da página
├── style.css    # visual hacker
├── script.js    # chuva de código, gerador de perfis, histórico e estatísticas
├── README.md
└── .gitignore
```

## Como rodar

Não precisa instalar nada. Abra o `index.html` no navegador.

Ou sirva localmente:

```bash
python3 -m http.server 8000
# acesse http://localhost:8000
```

## Publicar no GitHub

```bash
cd ghost-trace
git init
git add .
git commit -m "Primeira versão do GHOST.TRACE"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/ghost-trace.git
git push -u origin main
```

### Hospedar grátis com GitHub Pages

1. No repositório, abra **Settings → Pages**
2. Em **Source**, escolha **Deploy from a branch**
3. Selecione a branch `main` e a pasta `/ (root)`, depois salve
4. O site fica em `https://SEU-USUARIO.github.io/ghost-trace/`

## Observações

- Os números de acessos e investigações são simulados. Só "suas investigações" e o histórico são reais, guardados no seu navegador.
- Para um contador real de visitantes seria preciso um back-end ou um serviço externo.
- Fontes: [Share Tech Mono](https://fonts.google.com/specimen/Share+Tech+Mono) e [VT323](https://fonts.google.com/specimen/VT323), via Google Fonts.

## Aviso

Projeto apenas para estudo e demonstração. Não use para coletar ou expor dados de pessoas reais.
